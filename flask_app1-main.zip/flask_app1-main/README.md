# flask_app1
conexiones a bd.

Este proyecto es una practicatica desarrollada con el fin de 
practica
